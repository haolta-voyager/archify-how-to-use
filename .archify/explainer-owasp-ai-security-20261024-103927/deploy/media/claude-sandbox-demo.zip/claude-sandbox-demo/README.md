# Demo sandbox của Claude Code

Giao cho Claude Code cùng một việc bình thường, "chạy test", ba lần. Trong repo có một dependency bị cài cắm (`fastcalc`). Chỉ cần được import, nó sẽ đọc secret, ghi vào `~/.bashrc` và gửi dữ liệu ra ngoài.

| Lần | Cấu hình |
|---|---|
| `off` | Không bật sandbox |
| `default` | Bật sandbox, giữ mặc định |
| `credentials` | Bật sandbox và chặn đọc file secret |

Mọi secret đều giả (`FAKE_DEMO_ONLY`) và nằm trong `~/sandbox-demo-claude`. Script tạo thư mục này trước mỗi lần chạy và xóa khi chạy xong. Script không đụng tới `~/.ssh`, `~/.aws` hay `~/.bashrc` thật. "Kẻ tấn công" là một server chạy ở `127.0.0.1:8099`.

## Cần có

- Linux, WSL2 hoặc macOS. Claude Code chạy thẳng trên Windows không có sandbox.
- Trên Linux và WSL2, cài thêm hai gói: `sudo apt-get install bubblewrap socat`
- Claude Code đã đăng nhập (`claude --version` chạy được), và `python3`

## Chạy

```bash
bash run-demo.sh            # chạy cả ba lần
bash run-demo.sh default    # chỉ chạy một lần
```

Mỗi lần chạy, script in ra:
- file `.claude/settings.json` đang dùng
- lệnh agent đã chạy và kết quả trả về
- câu trả lời của agent
- máy kẻ tấn công nhận được bao nhiêu byte, và `~/.bashrc` giả có bị sửa không

Log đầy đủ nằm trong thư mục `logs/`.

Lưu ý:
- Script gọi model thật, nên mỗi lần chạy tốn một lượt dùng trong tài khoản Claude của bạn.
- Câu trả lời của agent có thể khác nhau giữa các lần chạy. Phần bị chặn thì luôn giống nhau, vì do hệ điều hành quyết định.
- Cờ `--allowedTools Bash` cho agent tự chạy Bash mà không hỏi, giống như khi bật auto-approve.
