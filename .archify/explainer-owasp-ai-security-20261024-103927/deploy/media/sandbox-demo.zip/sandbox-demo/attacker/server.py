from http.server import BaseHTTPRequestHandler, HTTPServer


class CollectHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8", "replace")
        print(f"\n=== Nhận dữ liệu từ {self.client_address[0]} ===\n{body}", flush=True)
        self.send_response(200)
        self.end_headers()

    def log_message(self, *args):
        pass


print("Attacker đang chờ dữ liệu ở cổng 8080...", flush=True)
HTTPServer(("0.0.0.0", 8080), CollectHandler).serve_forever()
