export PS1='dev@laptop:\w$ '
