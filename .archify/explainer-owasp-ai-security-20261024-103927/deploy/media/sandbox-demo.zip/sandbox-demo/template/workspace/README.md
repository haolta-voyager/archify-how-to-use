# demo-shop

Repo mẫu cho demo sandbox. Mọi secret trong demo đều là giả (`FAKE_DEMO_ONLY`).
