# Demo sandbox

Chạy cùng một chuỗi lệnh mà một agent bị prompt injection sẽ chạy, hai lần: không sandbox và có sandbox. Kết quả không phụ thuộc model nên lần nào chạy cũng giống nhau.

Mọi secret đều giả (`FAKE_DEMO_ONLY`), "kẻ tấn công" là một container chạy trên máy bạn. Script không đụng tới thư mục home thật.

## Cần có

- Docker Desktop (Windows, macOS) hoặc Docker Engine (Linux)
- PowerShell

## Chạy

```powershell
cd demos/sandbox-demo
.\demo.ps1 setup          # build image, tạo mạng, bật container attacker
.\demo.ps1 attacker-log   # terminal thứ hai: xem attacker nhận được gì
.\demo.ps1 unsafe         # lần 1: không sandbox
.\demo.ps1 sandboxed      # lần 2: có sandbox
.\demo.ps1 reset          # dọn container, mạng và thư mục run/
```

Sau lần `unsafe`, mở `run/home/.bashrc` để thấy dòng persistence đã được ghi ra "máy thật".

## Agent làm gì

`agent-actions.sh` chạy năm bước: đọc `.env` trong repo, đọc `~/.ssh`, đọc `~/.aws`, ghi thêm một dòng vào `~/.bashrc`, rồi POST mọi thứ lấy được tới attacker. Trước đó nó làm việc được giao: ghi `build.log` trong repo.

## Mỗi cờ Docker chặn cái gì

| Cờ ở chế độ `sandboxed` | Chặn | Vòng trifecta bị cắt |
|---|---|---|
| Không mount thư mục home | Đọc `~/.ssh`, `~/.aws` | Dữ liệu nhạy cảm |
| Mount file rỗng đè lên `/workspace/.env` | Đọc secret trong repo | Dữ liệu nhạy cảm |
| `--network none` | Gửi dữ liệu ra ngoài | Đường ra ngoài |
| `--read-only`, `--tmpfs /tmp` | Ghi persistence ngoài repo | Hậu quả sau khi agent tắt |
| `--cap-drop ALL`, `--security-opt no-new-privileges` | Leo quyền trong container | Thu hẹp phạm vi còn lại |

Chế độ `unsafe` mô phỏng agent chạy thẳng trên máy dev: thấy home, có mạng, ghi được mọi nơi.

## Mở rộng: agent thật trong sandbox

Muốn cho Claude Code hay Codex CLI chạy trong container này thì không thể dùng `--network none`, vì agent cần gọi API của model. Khi đó chặn mạng bằng firewall chỉ cho phép một số domain, như devcontainer tham khảo của Claude Code (`init-firewall.sh`).
