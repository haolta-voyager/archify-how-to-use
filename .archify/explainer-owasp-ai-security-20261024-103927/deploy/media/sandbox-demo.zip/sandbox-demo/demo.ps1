# Sandbox demo: run the same "injected agent" commands without and with a sandbox.
# Usage: .\demo.ps1 setup | unsafe | sandboxed | attacker-log | reset
param(
  [Parameter(Mandatory = $true)]
  [ValidateSet('setup', 'unsafe', 'sandboxed', 'attacker-log', 'reset')]
  [string]$Step
)

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$Root = $PSScriptRoot
$Run = Join-Path $Root 'run'
$Image = 'sandbox-demo-agent'
$Network = 'sandbox-demo-net'
$Attacker = 'sandbox-demo-attacker'
$Actions = "${Root}\agent-actions.sh:/demo/agent-actions.sh:ro"

function Assert-Ok($what) {
  if ($LASTEXITCODE -ne 0) { throw "$what failed (exit code $LASTEXITCODE)" }
}

# Each run starts from the template so the previous run's planted .bashrc line is gone.
function Reset-RunDir {
  if (Test-Path $Run) { Remove-Item -Recurse -Force $Run }
  New-Item -ItemType Directory -Force $Run | Out-Null
  Copy-Item -Recurse (Join-Path $Root 'template\workspace') (Join-Path $Run 'workspace')
  Copy-Item -Recurse (Join-Path $Root 'template\home') (Join-Path $Run 'home')
  Move-Item (Join-Path $Run 'workspace\env.fake') (Join-Path $Run 'workspace\.env')
  New-Item -ItemType File (Join-Path $Run 'empty') | Out-Null
}

function Remove-Attacker {
  if (docker ps -aq --filter "name=^${Attacker}$") { docker rm -f $Attacker | Out-Null }
}

switch ($Step) {
  'setup' {
    docker build -t $Image $Root; Assert-Ok 'docker build'
    if (-not (docker network ls -q --filter "name=^${Network}$")) {
      docker network create $Network | Out-Null; Assert-Ok 'docker network create'
    }
    Remove-Attacker
    docker run -d --name $Attacker --network $Network `
      -v "${Root}\attacker\server.py:/srv/server.py:ro" `
      python:3.12-alpine python -u /srv/server.py | Out-Null
    Assert-Ok 'start attacker'
    Reset-RunDir
    Write-Host 'Ready. Open a second terminal and run: .\demo.ps1 attacker-log'
  }
  'unsafe' {
    Reset-RunDir
    Write-Host '=== Without sandbox: agent sees your home folder and the network ===' -ForegroundColor Yellow
    docker run --rm -t --network $Network `
      -v "${Run}\workspace:/workspace" `
      -v "${Run}\home:/home/dev" `
      -v $Actions `
      $Image bash /demo/agent-actions.sh
  }
  'sandboxed' {
    Reset-RunDir
    Write-Host '=== With sandbox: only the repo, no network, no secrets ===' -ForegroundColor Green
    docker run --rm -t --network none --read-only --tmpfs /tmp `
      --cap-drop ALL --security-opt no-new-privileges `
      -v "${Run}\workspace:/workspace" `
      -v "${Run}\empty:/workspace/.env:ro" `
      -v $Actions `
      $Image bash /demo/agent-actions.sh
  }
  'attacker-log' {
    docker logs -f $Attacker
  }
  'reset' {
    Remove-Attacker
    if (docker network ls -q --filter "name=^${Network}$") { docker network rm $Network | Out-Null }
    if (Test-Path $Run) { Remove-Item -Recurse -Force $Run }
    Write-Host 'Cleaned up container, network and run folder.'
  }
}
